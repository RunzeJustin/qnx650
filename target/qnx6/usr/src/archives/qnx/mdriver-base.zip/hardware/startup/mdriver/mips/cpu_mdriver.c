/*
 * $QNXLicenseC:
 * Copyright 2007, QNX Software Systems. All Rights Reserved.
 * 
 * You must obtain a written license from and pay applicable license fees to QNX 
 * Software Systems before you may reproduce, modify or distribute this software, 
 * or any work that includes all or part of this software.   Free development 
 * licenses are available for evaluation and non-commercial purposes.  For more 
 * information visit http://licensing.qnx.com or email licensing@qnx.com.
 *  
 * This file may contain contributions from others.  Please review this entire 
 * file for other proprietary rights or license notices, as well as the QNX 
 * Development Suite License Guide at http://licensing.qnx.com/license-guide/ 
 * for other information.
 * $
 */




#include "startup.h"

ptrdiff_t
cpu_mdriver_map(void) {
	//Need to make sure that startup code is mapped into the
	//system address space so that mini-drivers are accessable from
	//the kernel.

	//Nothing to do
	return 0;
}	

void *
cpu_mdriver_prepare(struct mdriver_entry *md) {
	//Return a pointer that will map the md->data_paddr memory
	//for md->data_size bytes while the kernel is running.

	return md->data;
}
