/*
 * Title: Sorting Knuth
 * Date:  Sept 1, 1999
 * From:  Marc Tardif aka MrPickle
 * Email: intmktg@cam.org
 *
 * To compile: cc file.c -lm
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <unistd.h>  

#define u 0     /* minimal key value */
#define v 16    /* maximal key value, inclusive */

#define pop(a, b)       a = (--St)->i, b = St->j, S-=1
#define push(a, b)      St->i = a, (St++)->j = b, S+=1
#define swap(a, b, t)   t = a, a = b, b = t
#define set(a,b)        ((b<0)?set2(a,-b):set2(a,b))
#define set2(a,b)       ((a<0)?-b:b)
  
    
typedef struct {
	
	int K;		/* Key */
	int L;		/* Link */
} RECORD;

typedef struct {
	int i;		/* not significant */
	int j;		/* not significant */
} STACK;

typedef enum {
	LOW,
	HIGH
} ROUND;

void ins(RECORD **, int);       /* Straight insertion */
void shl(RECORD **, int);       /* Shell's method */
void lins(RECORD **, int);      /* List insertion */
void bubble(RECORD **, int);    /* Bubble sort */
void merge(RECORD **, int);     /* Merge exchange */
void quick(RECORD **, int);     /* Quicksort */
void radix(RECORD **, int);     /* Radix exchange sort */
void straight(RECORD **, int);  /* Straight selection sort */
void heap(RECORD **, int);      /* Heapsort */
//void tmerge(RECORD **, int);    /* Two-way merge */
//void ntmerge(RECORD **, int);   /* Natural two-way merge sort */
//void stmerge(RECORD **, int);   /* Straight two-way merge sort */
//void lmerge(RECORD **, int);    /* List merge sort */

void fill(RECORD **, int);
void printarray(RECORD **, int);
void printlist(RECORD **);
void fatal(char *);
void usage(void);

struct funcs {
	char *name;
	void (*sortf)(RECORD **, int);
};

struct funcs sortfuncs[8] = { {"ins", ins}, {"shl", shl}, {"bubble", bubble}, 
							   {"merge", merge}, {"quick", quick}, {"radix", radix},
							   {"heap", heap}, {"straight", straight} };

int lg(int, ROUND);

int main(int argc, char *argv[]) {
	RECORD **R;
	int i, j, N;

	/* Number of records */
	N = 10000;

	if (!(R = (RECORD **)malloc((N+1)*sizeof(RECORD *)))) {
		fatal("malloc");
	}
	for (i=0; i<=N; i++) {
		if (!(R[i] = (RECORD *)malloc(sizeof(RECORD)))) {
			fatal("malloc");
		}
	}

	for(j = 0; j < 10; j++) { 
		for(i = 0; i < 8; i++) {
			fill(R, N);
			sortfuncs[i].sortf(R, N);
		}
		delay(10);
	}

	if (R[0]->L) {
		printlist(R);
	} else {
		printarray(R, N);
	}
		
	return(5);
}

void ins(RECORD **R, int N) {
		int i, j, Kt;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));

		for (j=2; j<=N; j+=1) {
			i=j-1; Kt=R[j]->K; Rt=R[j];
S3:			if (Kt>=R[i]->K) goto S5;
			R[i+1]=R[i]; i-=1; if (i>0) goto S3;
S5:			R[i+1]=Rt; }
		free(Rt);
}

void shl(RECORD **R, int N) {
		int i, j, h, Kt;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));

 		for (h=N/2; h>0; h/=2) {
			for (j=h+1; j<=N; j+=1) {
				i=j-h; Kt=R[j]->K; Rt=R[j];
D4:				if (Kt>=R[i]->K) goto D6;
				R[i+h]=R[i]; i-=h; if (i>0) goto D4;
D6:				R[i+h]=Rt; } }
		free(Rt);
}

void lins(RECORD **R, int N) {
		int j, p, q, Kt;

		R[0]->L=N; R[N]->L=0; for (j=N-1; j>=1; j-=1) {
			p=R[0]->L; q=0; Kt=R[j]->K;
L3:			if (Kt<=R[p]->K) goto L5;
			q=p; p=R[q]->L; if (p>0) goto L3;
L5:			R[q]->L=j; R[j]->L=p; }
}

void bubble(RECORD **R, int N) {
		int j, t, BOUND;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));

		BOUND=N;
B2:		t=0; for (j=1; j<=BOUND-1; j+=1) {
			if (R[j]->K>R[j+1]->K) swap(R[j],R[j+1],Rt); t=j; }
		if (t!=0) { BOUND=t; goto B2; }
		free(Rt);
}

void merge(RECORD **R, int N) {
		int i, j, d, p, q, r, t;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));

		t=lg(N, HIGH); for (j=1, p=pow(2,t-1); p>=1; p=pow(2,t-(j++))) {
M2:			q=pow(2, t-1); r=0; d=p;
M3:			for (i=0; i<N-d; i+=1) if ((i&p)==r) {
				if (R[i+1]->K>R[i+d+1]->K) swap(R[i+1],R[i+d+1],Rt); }
			if (q!=p) { d=q-p; q=q/2; r=p; goto M3; } }
		p=p/2; if (p>0) goto M2;

		free(Rt);
}

void quick(RECORD **R, int N) {
		int i, j, l, r, K, S;
		int M = 7;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));
		STACK *St = (STACK *)malloc((lg(N, HIGH)+1)*sizeof(STACK));

		if (N<=M) goto Q9; 
		S=0; l=1; r=N;
Q2:		i=l; j=r+1; K=R[l]->K;
Q3:		i+=1; if (R[i]->K<K) goto Q3;
Q4:		j-=1; if (K<R[j]->K) goto Q4;
		if (j<=i) { swap(R[l],R[j],Rt); goto Q7; }
		swap(R[i],R[j],Rt); goto Q3;
Q7:		if (r-j>=j-l && j-l>M) { push(j+1,r); S+=1; r=j-1; goto Q2; }
		if (j-l>r-j && r-j>M) { push(l,j-1); S+=1; l=j+1; goto Q2; }
		if (r-j>M && M>=j-l) { l=j+1; goto Q2; }
		if (j-l>M && M>=r-j) { r=j-1; goto Q2; }
		if (S) { pop(l,r); S-=1; goto Q2; }
Q9:		for (j=2; j<=N; j+=1) {
			if (R[j-1]->K > R[j]->K) {
					K=R[j]->K; Rt=R[j]; i=j-1; R[i+1]=R[i];
					while (R[i]->K>K && i>=1) i-=1;
					R[i+1]=Rt; } }
		free(Rt);
		free(St);
}

void radix(RECORD **R, int N) {
		int i, j, b, l, m, r, S;
		STACK *St;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));

		m = (sizeof(int)*8);
		St = (STACK *)malloc((m-1)*sizeof(STACK));

		S=0; l=1; r=N; b=N;
R2:		if (l==r) goto R10; i=l; j=r;
R3:		if (R[i]->K & 1<<(b-1)) goto R6;
R4:		i+=1; if (i<=j) goto R3; goto R8;
R5:		if (!(R[j+1]->K & 1<<(b-1))) goto R7;
R6:		j-=1; if (i<=j) goto R5; goto R8;
R7:		swap(R[i],R[j+1],Rt); goto R4;

R8:		b-=1; if (b<0) goto R10;
		if (j<l || j==r) goto R2;
		if (j==l) { l+=1; goto R2; }
		push(r,b); r=j; goto R2;
R10:	if (S) { l=r+1; pop(r,b); goto R2; }
		free(Rt);
		free(St);
}

void straight(RECORD **R, int N) {
		int i, j, k;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));

		for (j=N; j>=2; j-=1) {
			for (i=j, k=j-1; k>=1; k-=1) if (R[k]->K>R[i]->K) i=k;
			swap(R[i],R[j],Rt); }
		free(Rt);	
}

void heap(RECORD **R, int N) {
		int i, j, l, r, Kt;
		RECORD *Rt = (RECORD *)malloc(sizeof(RECORD));

		l=N/2+1; r=N;
H2:		if (l>1) { l-=1; Rt=R[l]; Kt=R[l]->K; }
		else { Rt=R[r]; Kt=R[r]->K; R[r]=R[1]; r-=1;
			if (r==1) { R[1]=Rt; goto END; } }
		j=l;
H4:		i=j; j*=2; if (j<r) goto H5; if (j==r) goto H6; if (j>r) goto H8;
H5:		if (R[j]->K<R[j+1]->K) j+=1;
H6:		if (Kt>=R[j]->K) goto H8;
		R[i]=R[j]; goto H4;
H8:		R[i]=Rt; goto H2;
END:
		free(Rt);
}

void tmerge(RECORD **R, int N) {
		int i, j, k, m, n;
		RECORD **x, **y, **z;

		m = n = N/2;
		x = (RECORD **)malloc((m+1)*sizeof(RECORD *));
		for (i=1; i<=m; i++) {
			x[i] = (RECORD *)malloc(sizeof(RECORD));
			x[i]->K = R[i]->K; x[i]->L = i;
		}
		ins(x, N/2);
		y = (RECORD **)malloc((n+1)*sizeof(RECORD *));
		for (j=1; j<=n; j++) {
			y[j] = (RECORD *)malloc(sizeof(RECORD));
			y[j]->K = R[j+i-1]->K; y[j]->L = j;
		}
		ins(y, N/2);
		z = R;

		i=1; j=1; k=1;
M2:		if (x[i]->K<=y[j]->K) goto M3; else goto M5;
M3:		z[k]->K=x[i]->K; k+=1; i+=1; if (i<=m) goto M2;
		while (k<=m+n || j<=n) z[k++]->K=y[j++]->K; goto END;
M5:		z[k]->K=y[j]->K; k+=1; j+=1; if (j<=n) goto M2;
		while (k<=m+n || i<=m) z[k++]->K=x[i++]->K; goto END;
END:
		free(x);
		free(y);
}


void fill(RECORD **R, int N) {
	int i;

	srand(time(NULL));
	R[0]->K = N;
	R[0]->L = 0;
	for (i=1; i<=N; i++) {
		R[i]->K = u + (rand()%(v-u+1));
		R[i]->L = i;
	}
}

void printarray(RECORD **R, int N) {
	int i;

	for (i=0; i<=N; i++) {
		printf("i: %3d\tR->K: %3d\tR->L: %3d\n", i, R[i]->K, R[i]->L);
	}
}

void printlist(RECORD **R) {
	int i;

	i = 0;
	do {
		printf("i: %3d\tR->K: %3d\tR->L: %3d\n", i, R[i]->K, R[i]->L);
		i=R[i]->L;
	} while (R[i]->L);
}

int lg(int i, ROUND r) {
	int a;
	double b;

	a = (int)(log10((double)i)/log10(2));
	b = log10((double)i)/log10(2);
	if ((double)a < b)
		if (r) a+=1;
	return a;
}

void fatal(char *msg) {
	fprintf(stderr, "ERROR: %s\n", msg);
	exit(1);
}

void usage(void) {
	printf(
"Usage:"
"  a.out [options]"
"Options:"
"  -c   Comparison counting"
"  -d   Distribution counting"
"  -i   Straight insertion"
"  -e   Shell's method"
"  -l   List insertion"
"  -b   Bubble sort"
"  -m   Merge exchange"
"  -q   Quicksort"
"  -r   Radix exchange sort"
"  -s   Straight selection sort"
"  -h   Heapsort"
"  -t   Two-way merge"
"  -n   Natural two-way merge sort"
"  -g   Straight two-way merge sort"
"  -w   List merge sort"
);
	exit(0);
}


