/*
 *  rbt_client.c
 *
 *  This provides a sample for trying out debugging message passing.
 *  This is for use with the rbt_server process.  This will do a name lookup
 *  for the name that rbt_server registers.  It will then send rbt_server
 *  whatever message you tell it to using "run" function (called from main),
 *  rbt_server will receive the message and reply back with a simple reply.
 *
 *  Run rbt_server first.  Then run rbt_client. Add more commands in the "main" to increase coverage.
 *  run('s', "hello"); // robot says hello
 *  run('r', "r"); // raise right hand
 *  run('l', "r"); // lower right hand
 *  run('r', "l"); // raise left hand
 *  run('l', "l"); // lower left hand
*/


#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/dispatch.h>

#include "rbt_server.h"

void options (int argc, char **argv);

char *name = RBT_SERVER_NAME;	/* the name that we rbt_server registers and
								   that we look up */
rs_msgs_t msg;			/* the message we will send to rbt_server, gotten
						   from the command line */
char *msgdesc;			/* message description for diagnostics */
char *progname;

int
send_command()
{
    int coid;
    struct timespec stime;


    setvbuf(stdout, NULL, _IOLBF, BUFSIZ );

	/* fill in our nanosleep time for below */
	stime.tv_sec = 0;
	stime.tv_nsec = 100000000; /* 100 milliseconds */
	
	/*
	 * go into a loop, looking for rbt_server.  We loop because rbt_server may
	 * not be running yet.
	*/
	while (1) {
	    if ((coid = name_open (name, 0)) != -1) {
	    	break; /* found it, name_open() succeeded */
	    } else if (errno != ENOENT) {
	        fprintf (stderr, "%s:  name_open() failed: %s\n", progname, strerror(errno));
 	        exit (EXIT_FAILURE);
	    }
		/*
		 * else errno == ENOENT meaning name not attached yet,
		 * wait a bit, so that we don't hog the CPU, and try again
		*/
		nanosleep (&stime, NULL);
	}
	  
	/* send message to rbt_server.  The message was prepared in options() below */
    if (MsgSend (coid, &msg, sizeof(msg), NULL, 0) == -1) {
        fprintf (stderr, "%s:  MsgSend() failed: %s\n", progname, strerror(errno));
        exit (EXIT_FAILURE);
    }

	printf ("%s:  sent '%s' message\n", progname, msgdesc);
    	
    name_close (coid);
    
    return 0;
}

static int parse(char c, char * optarg);

static void run(char c, char * optarg) {
	parse(c, optarg);
	send_command();
}

int
main(int argc, char **argv)
{	
    progname = argv[0];
    options (argc, argv);
    // add more commands
    return EXIT_SUCCESS;
}

int parse(char c, char * optarg) {
    switch (c) {
    case 'n':
        name = optarg;
        break;
    case 'r':
    	switch (*optarg) {
    	case 'l':
    		msg.type = RS_MSGTYPE_RAISE_LEFT_ARM;
    		msgdesc = "raise left arm";
    		break;
    	case 'r':
    		msg.type = RS_MSGTYPE_RAISE_RIGHT_ARM;
    		msgdesc = "raise right arm";
    		break;
    	}
    	break;
    case 'l':
    	switch (*optarg) {
    	case 'l':
    		msg.type = RS_MSGTYPE_LOWER_LEFT_ARM;
    		msgdesc = "lower left arm";
    		break;
    	case 'r':
    		msg.type = RS_MSGTYPE_LOWER_RIGHT_ARM;
    		msgdesc = "lower right arm";
    		break;
    	}
    	break;
    case 's':
    	msg.type = RS_MSGTYPE_SAY;
    	strncpy (msg.say.text, optarg, RS_MAX_TEXT_LEN);
    	msg.say.text[RS_MAX_TEXT_LEN] = '\0';
		msgdesc = "say";
    	break;
    case 'd':
    	msg.type = RS_MSGTYPE_DIE;
		msgdesc = "die";
    	break;
    default:
    	return 0;
    }
    return 1;
}
void
options (int argc, char **argv)
{
	int c;
	
	msg.type = 0;
	
    while ((c = getopt (argc, argv, "n:r:l:s:d")) != -1) {
    	run(c, optarg);
    }

    if (msg.type == 0) {
        fprintf (stderr, "%s:  No command was given on command line.\n"
        				 "use: %s [option] command\n"
        				 "Option:\n"
        				 "-n name     Name rbt_server registered.\n\n"
        				 "Commands:\n"
        				 "-r [l|r]    Raise left (l) arm or right (r) arm.\n"
        				 "-l [l|r]    Lower left (l) arm or right (r) arm.\n"
        				 "-s text     Some text for the robot to say\n"
        				 "-d          Die (stop the server)\n",
        				 progname, progname);
        exit (EXIT_FAILURE);
    }
}
