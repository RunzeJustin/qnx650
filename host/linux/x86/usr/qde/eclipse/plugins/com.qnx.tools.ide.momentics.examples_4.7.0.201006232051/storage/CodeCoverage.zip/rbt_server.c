
/*
 *  rbt_server.c
 *
 *  This provides a sample for trying out debugging message passing.
 *  This is for use with the rbt_client process.  This will register a name
 *  so that rbt_client can find us.  It will then go into a receive loop
 *  and wait for messages.  As it receives messages, it will handle them
 *  and reply.
 * 
 *  This is pretending to be a process managing the actions of a robot.
 *  The robot pretends to be able to talk and to raise and lower its left 
 *  and right arms.  To get it to do this, a program called rbt_client
 *  can send it messages.
 * 
 *  Run rbt_server first.  Then run rbt_client. See instructions in rbt_client.c
 * 
*/

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/dispatch.h>

#include "rbt_server.h"

static void say (int rcvid, char *text);
static void die (int rcvid);
static void raise_left_arm (int rcvid);
static void lower_left_arm (int rcvid);
static void raise_right_arm (int rcvid);
static void lower_right_arm (int rcvid);
static void handle_pulse (struct _pulse *pulse);
static void options (int argc, char **argv);

char *name = RBT_SERVER_NAME;	/* the name that we register and that
								   rbt_client looks up */

/*
 * rbs_msgs_t is a union of all the types of messages we expect to receive.
 * In our MsgReceive() below, we will need a message buffer that is big
 * enough for our largest expected message since we could receive any of them
 * at any time.  A union is an easy way of doing that.  We expect to receive
 * pulse messages (of type struct _pulse) and the message from rbt_client
*/
typedef union {
	uint16_t		type;
    struct _pulse  pulse;
	rs_msgs_t		rbt_msg;
} message_buf_t;

#define LOWERED	0
#define RAISED		1

int left_arm_state = LOWERED;
int right_arm_state = LOWERED;

char *progname;

int
main(int argc, char **argv)
{
    int rcvid;
    message_buf_t msg;
    name_attach_t *attach;

    progname = argv[0];
    setvbuf(stdout, NULL, _IOLBF, BUFSIZ );
	options (argc, argv);

	/* register the name that rbt_client will look up in order to find us. */
    if ((attach = name_attach (NULL, name, 0)) == NULL) {
        fprintf (stderr, "%s:  name_attach failed: %s\n", progname, strerror(errno));
        exit (EXIT_FAILURE);
    }

    while (1) {
    	/*
    	 * wait for a message.  If there is none already then this will not
    	 * return until there is one.
    	*/
        rcvid = MsgReceive (attach->chid, &msg, sizeof(msg), NULL);

		/*
		 * rcvid will be 0 if we received a pulse message.  Our client is not
		 * sending pulse messages so rcvid will not be 0 in that case.  So
		 * for seeing what happens when we receive a message from a client
		 * see further below.
		*/
        if (rcvid == 0) {/* Pulse received */
			handle_pulse (&msg.pulse);
            continue;
        }
        
        if (msg.type >= _IO_BASE && msg.type <= _IO_MAX) {
         //If we we receive one by accident, tell client we don't handle these msg types
        	MsgError (rcvid, ENOSYS);
    	}
    	
		/*
		 * we got a message from a client.
		*/
		
		switch (msg.type) {
		case RS_MSGTYPE_SAY:
			say (rcvid, msg.rbt_msg.say.text);
			break;
		case RS_MSGTYPE_RAISE_LEFT_ARM:
			raise_left_arm (rcvid);
			break;
		case RS_MSGTYPE_LOWER_LEFT_ARM:
			lower_left_arm (rcvid);
			break;
		case RS_MSGTYPE_RAISE_RIGHT_ARM:
			raise_right_arm (rcvid);
			break;
		case RS_MSGTYPE_LOWER_RIGHT_ARM:
			lower_right_arm (rcvid);
		    break;
		case RS_MSGTYPE_DIE:
			die (rcvid);
			break;
		}
    }
}

static void
die (int rcvid)
{
	printf ("%s:  robot died\n", progname);
	if (MsgReply (rcvid, EOK, NULL, 0) == -1) {
		fprintf (stderr, "%s:  MsgReply() failed\n", progname);
	}
	exit(0);
}

static void
say (int rcvid, char *text)
{
	/* pretend we make the robot say the text */
	printf ("%s:  robot said '%s'\n", progname, text);
	if (MsgReply (rcvid, EOK, NULL, 0) == -1) {
		fprintf (stderr, "%s:  MsgReply() failed\n", progname);
	}
}

static void
raise_left_arm (int rcvid)
{
	if (left_arm_state == LOWERED) {
		/* pretend we make the robot raise its left arm */
		printf ("%s:  robot raised left arm\n", progname);
		left_arm_state = RAISED;
	} else
		printf ("%s:  left arm already raised\n", progname);
	if (MsgReply (rcvid, EOK, NULL, 0) == -1) {
		fprintf (stderr, "%s:  MsgReply() failed\n", progname);
	}
}

static void
lower_left_arm (int rcvid)
{
	if (left_arm_state == RAISED) {
		/* pretend we make the robot lower its left arm */
		printf ("%s:  robot lowered left arm\n", progname);
		left_arm_state = LOWERED;
	} else
		printf ("%s:  left arm already lowered\n", progname);
	if (MsgReply (rcvid, EOK, NULL, 0) == -1) {
		fprintf (stderr, "%s:  MsgReply() failed\n", progname);
	}
}

static void
raise_right_arm (int rcvid)
{
	if (right_arm_state == LOWERED) {
		/* pretend we make the robot raise its right arm */
		printf ("%s:  robot raised right arm\n", progname);
		right_arm_state = RAISED;
	} else
		printf ("%s:  right arm already raised\n", progname);
	if (MsgReply (rcvid, EOK, NULL, 0) == -1) {
		fprintf (stderr, "%s:  MsgReply() failed\n", progname);
	}
}

static void
lower_right_arm (int rcvid)
{
	if (right_arm_state == RAISED) {
		/* pretend we make the robot lower its right arm */
		printf ("%s:  robot lowered right arm\n", progname);
		right_arm_state = LOWERED;
	} else
		printf ("%s:  right arm already lowered\n", progname);
    if (MsgReply (rcvid, EOK, NULL, 0) == -1) {
		fprintf (stderr, "%s:  MsgReply() failed\n", progname);
	}
}

/*
 * handle_pulse
 * 
 * Because we did a name_attach(), we can expect the kernel to
 * send us pulse messages under certain circumstances.  See the
 * name_attach() docs for more.
*/
static void
handle_pulse (struct _pulse *pulse)
{
    switch (pulse->code) {
    case _PULSE_CODE_DISCONNECT:
        /*
         * a client disconnected all its connections (called
         * name_close() for each name_open() of our name) or
         * terminated
         */
        ConnectDetach (pulse->scoid);
        break;
    case _PULSE_CODE_UNBLOCK:
        /*
         * REPLY blocked client wants to unblock (was hit by
         * a signal or timed out).  It is up to you if you
         * reply now or later.
         * 
         * we don't care
         */
        break;
    case _PULSE_CODE_THREADDEATH:
        /*
         * a thread in this process died
         * 
         * does not apply to this process
         */
        break;
    default:
        /* a pulse sent by one of your processes? */
        fprintf (stderr, "%s:  unexpected pulse, code = 0x%X\n", 
        	progname, pulse->code);
    }
}

static void
options (int argc, char **argv)
{
	int c;
	
    while ((c = getopt (argc, argv, "n:")) != -1) {
        switch (c) {
        case 'n':
            name = optarg;
            break;
        }
    }
}
